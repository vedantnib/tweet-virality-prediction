#Group Members:
#Ameya Potey, NetId: ANP200000
#Koushik Grandhi, NetId: KXG190042
#Vedant Nibandhe, NetId: VXN200012

apiKey = ""
apiKeySecret = ""
bearerToken = ""
accessToken = ""
accessTokenSecret = ""
dataset_path = "random_tweets.json"